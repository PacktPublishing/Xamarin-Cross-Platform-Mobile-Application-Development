﻿using System;
using System.Linq;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Xamarin.Contacts;

namespace Contacts.Droid
{
	[Activity(Label = "Contacts", MainLauncher = true, Icon = "@drawable/icon")]
	public class MainActivity : Activity
	{
		protected async override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);
			SetContentView(Resource.Layout.Main);
			var listView = FindViewById<ListView>(Resource.Id.contacts);
			var adapter = new ContactsAdapter();
			listView.Adapter = adapter;
			try
			{
				var book = new AddressBook(this);
				await book.RequestPermission();
				adapter.Contacts = book.ToArray();
				adapter.NotifyDataSetChanged();
			}
			catch
			{
				new AlertDialog.Builder(this).SetTitle("Oops")
					.SetMessage("Something went wrong, try again later.")
					.SetPositiveButton("Ok", delegate { }).Show();
			}
		}

		class ContactsAdapter : BaseAdapter<Contact>
		{
			public Contact[] Contacts { get; set; }
			public override long GetItemId(int position)
			{
				return position;
			}
			public override View GetView(
				int position, View convertView, ViewGroup parent)
			{
				var contact = this [position];
				var textView = convertView as TextView;
				if (textView == null)
				{
					textView = new TextView(parent.Context);
				}
				textView.Text = contact.LastName + ", " + contact.FirstName;
				return textView;
			}
			public override int Count
			{
				get { return Contacts == null ? 0 : Contacts.Length; }
			}
			public override Contact this[int index]
			{
				get { return Contacts [index]; }
			}
		}
	}
}


