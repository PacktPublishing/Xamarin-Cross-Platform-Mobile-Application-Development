using System;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using Xamarin.Contacts;

namespace Contacts.iOS
{
	partial class ContactsController : UITableViewController, IUITableViewDataSource
	{
		const string CellName = "ContactsCell";
		Contact[] contacts;

		public ContactsController (IntPtr handle) : base (handle)
		{
			Title = "Contacts";
		}

		public async override void ViewDidLoad()
		{
			base.ViewDidLoad();
			try
			{
				var book = new AddressBook();
				await book.RequestPermission();
				contacts = book.ToArray();
			}
			catch
			{
				new UIAlertView("Oops!", "Something went wrong, try again later.", null, "Ok").Show();
			}
		}

		public override int RowsInSection(UITableView tableview, int section)
		{
			return contacts != null ? contacts.Length : 0;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			var contact = contacts [indexPath.Row];
			var cell = tableView.DequeueReusableCell(CellName);
			if (cell == null)
				cell = new UITableViewCell(UITableViewCellStyle.Default, CellName);
			cell.TextLabel.Text = contact.LastName + ", " + contact.FirstName;
			return cell;
		}
	}
}
