// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using System;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.CodeDom.Compiler;

namespace Camera.iOS
{
	[Register ("CameraController")]
	partial class CameraController
	{
		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIButton camera { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIImageView imageView { get; set; }

		[Outlet]
		[GeneratedCode ("iOS Designer", "1.0")]
		UIButton library { get; set; }

		void ReleaseDesignerOutlets ()
		{
			if (camera != null) {
				camera.Dispose ();
				camera = null;
			}
			if (imageView != null) {
				imageView.Dispose ();
				imageView = null;
			}
			if (library != null) {
				library.Dispose ();
				library = null;
			}
		}
	}
}
