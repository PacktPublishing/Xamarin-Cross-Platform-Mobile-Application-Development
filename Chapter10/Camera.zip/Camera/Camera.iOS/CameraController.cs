using System;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.CodeDom.Compiler;
using Xamarin.Media;

namespace Camera.iOS
{
	partial class CameraController : UIViewController
	{
		MediaPicker picker;

		public CameraController (IntPtr handle) : base (handle)
		{
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();
			picker = new MediaPicker();
			if (!picker.IsCameraAvailable)
				camera.Enabled = false;
			camera.TouchUpInside += OnCamera;
			library.TouchUpInside += OnLibrary;
		}

		async void OnCamera (object sender, EventArgs e)
		{
			try
			{
				var file = await picker.TakePhotoAsync(new StoreCameraMediaOptions());
				imageView.Image = ToImage(file);
			}
			catch
			{
				ShowError();
			}
		}

		async void OnLibrary (object sender, EventArgs e)
		{
			try
			{
				var file = await picker.PickPhotoAsync();
				imageView.Image = ToImage(file);
			}
			catch
			{
				ShowError();
			}
		}

		UIImage ToImage(MediaFile file)
		{
			using (var stream = file.GetStream())
			{
				using (var data = NSData.FromStream(stream))
				{
					return UIImage.LoadFromData(data);
				}
			}
		}

		void ShowError()
		{
			new UIAlertView("Oops!", "Something went wrong, try again later.", null, "Ok").Show();
		}
	}
}
