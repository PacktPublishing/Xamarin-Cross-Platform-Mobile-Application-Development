﻿using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Xamarin.Media;
using Android.Graphics;

namespace Camera.Droid
{
	[Activity(Label = "Camera", MainLauncher = true, Icon = "@drawable/icon")]
	public class MainActivity : Activity
	{
		MediaPicker picker;
		ImageView imageView;

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);
			SetContentView(Resource.Layout.Main);
			var library = FindViewById<Button>(Resource.Id.library);
			var camera = FindViewById<Button>(Resource.Id.camera);
			imageView = FindViewById<ImageView>(Resource.Id.imageView);
			picker = new MediaPicker(this);
			library.Click += OnLibrary;
			camera.Click += OnCamera;
			if (!picker.IsCameraAvailable)
				camera.Enabled = false;
		}

		void OnLibrary (object sender, EventArgs e)
		{
			var intent = picker.GetPickPhotoUI();
			StartActivityForResult (intent, 1);
		}

		void OnCamera (object sender, EventArgs e)
		{
			var intent = picker.GetTakePhotoUI(new StoreCameraMediaOptions
			{
				Name = "test.jpg",
				Directory = "PhotoPicker"
			});
			StartActivityForResult (intent, 1);
		}

		protected async override void OnActivityResult(int requestCode, Result resultCode, Intent data)
		{
			if (resultCode == Result.Canceled)
				return;
			var file = await data.GetMediaFileExtraAsync(this);
			using (var stream = file.GetStream())
			{
				imageView.SetImageBitmap(await BitmapFactory.DecodeStreamAsync(stream));
			}
		}
	}
}


