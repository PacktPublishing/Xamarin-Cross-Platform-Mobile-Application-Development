﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace HelloAndroid
{
	[Activity(Label = "HelloAndroid", MainLauncher = true, Icon = "@drawable/icon")]
	public class MainActivity : Activity
	{
		int count = 0;

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			// Set our view from the "main" layout resource
			SetContentView(Resource.Layout.Main);

			TextView text = FindViewById<TextView>(Resource.Id.myText);
			Button button = FindViewById<Button>(Resource.Id.myButton);
			
			button.Click += delegate
			{
				text.Text = string.Format("Count: {0}", ++count);

				StartActivity(typeof(SecondActivity));
			};
		}
	}
}


