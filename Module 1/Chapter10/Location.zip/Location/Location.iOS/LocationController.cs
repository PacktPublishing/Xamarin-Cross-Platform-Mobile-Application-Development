using System;
using System.Collections.Generic;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using Xamarin.Geolocation;

namespace Location.iOS
{
	partial class LocationController : UITableViewController, IUITableViewDataSource
	{
		const string CellName = "LocationCell";
		Geolocator locator;
		List<string> messages = new List<string>();

		public LocationController (IntPtr handle) : base (handle)
		{
			Title = "GPS";
			locator = new Geolocator();
			locator.PositionChanged += OnPositionChanged;
			locator.PositionError += OnPositionError;
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();
			locator.StartListening(1000, 50);
		}

		void OnPositionChanged (object sender, PositionEventArgs e)
		{
			messages.Add(string.Format("Long: {0:0.##} Lat: {1:0.##}", e.Position.Longitude, e.Position.Latitude));
			TableView.ReloadData();
		}

		void OnPositionError (object sender, PositionErrorEventArgs e)
		{
			messages.Add(e.Error.ToString());
			TableView.ReloadData();
		}

		public override int RowsInSection(UITableView tableview, int section)
		{
			return messages.Count;
		}

		public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
		{
			var cell = tableView.DequeueReusableCell(CellName);
			if (cell == null)
				cell = new UITableViewCell(UITableViewCellStyle.Default, CellName);
			cell.TextLabel.Text = messages [indexPath.Row];
			return cell;
		}
	}
}
