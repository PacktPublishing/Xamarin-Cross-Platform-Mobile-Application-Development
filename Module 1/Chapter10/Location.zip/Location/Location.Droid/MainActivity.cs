﻿using System;
using System.Collections.Generic;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Xamarin.Geolocation;

namespace Location.Droid
{
	[Activity(Label = "GPS Location", MainLauncher = true, Icon = "@drawable/icon")]
	public class MainActivity : Activity
	{
		Geolocator locator;
		Adapter adapter;

		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);
			SetContentView(Resource.Layout.Main);
			var listView = FindViewById<ListView>(Resource.Id.locations);
			listView.Adapter =
				adapter = new Adapter();
			locator = new Geolocator(this);
			locator.PositionChanged += OnPositionChanged;
			locator.PositionError += OnPositionError;
		}

		protected override void OnResume()
		{
			base.OnResume();
			locator.StartListening(1000, 50);
		}

		protected override void OnPause()
		{
			base.OnPause();
			locator.StopListening();
		}

		void OnPositionChanged (object sender, PositionEventArgs e)
		{
			adapter.Add(string.Format("Long: {0:0.##} Lat: {1:0.##}", e.Position.Longitude, e.Position.Latitude));
		}

		void OnPositionError (object sender, PositionErrorEventArgs e)
		{
			adapter.Add(e.Error.ToString());
		}

		class Adapter : BaseAdapter<string>
		{
			List<string> messages = new List<string>();

			public void Add(string message)
			{
				messages.Add(message);
				NotifyDataSetChanged();
			}

			public override long GetItemId(int position)
			{
				return position;
			}

			public override View GetView(int position, View convertView, ViewGroup parent)
			{
				var textView = convertView as TextView;
				if (textView == null)
					textView = new TextView(parent.Context);
				textView.Text = messages [position];
				return textView;
			}

			public override int Count
			{
				get { return messages.Count; }
			}

			public override string this[int index]
			{
				get { return messages [index]; }
			}
		}
	}
}


