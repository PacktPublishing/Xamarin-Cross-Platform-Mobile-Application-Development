﻿using System;
using Xamarin.Forms;

[assembly: Dependency(typeof(XamChat.Core.FakeWebService))]
[assembly: Dependency(typeof(XamChat.Core.FakeSettings))]

namespace XamChat.Core
{
	public class App
	{
		public static Page GetMainPage()
		{	
			return new NavigationPage(new LoginPage());
		}
	}
}

