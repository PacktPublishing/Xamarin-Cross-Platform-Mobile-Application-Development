﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace XamChat.Core
{	
	public partial class ConversationsPage : ContentPage
	{	
		readonly MessageViewModel messageViewModel = new MessageViewModel();

		public ConversationsPage()
		{
			Title = "Conversations";
			BindingContext = messageViewModel;

			InitializeComponent ();

			Appearing += async (sender, e) => 
			{
				try
				{
					await messageViewModel.GetConversations();
				}
				catch (Exception exc)
				{
					await DisplayAlert("Oops!", exc.Message, "Ok");				
				}
			};
		}
	}
}

