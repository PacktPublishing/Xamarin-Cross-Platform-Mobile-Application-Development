﻿﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace UIDemo
{	
	public partial class UIDemoPage : ContentPage
	{	
		public UIDemoPage ()
		{
			InitializeComponent ();
		}
	}
}

