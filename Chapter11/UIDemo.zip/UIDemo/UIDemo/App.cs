﻿using System;
using Xamarin.Forms;

namespace UIDemo
{
	public class App
	{
		public static Page GetMainPage()
		{	
			return new UIDemoPage();
		}
	}
}

