﻿using System;

namespace GoogleAnalytics
{
	public enum GAILogLevel : uint {
		None = 0,
		Error = 1,
		Warning = 2,
		Info = 3,
		Verbose = 4
	}

	public enum GAIDispatchResult : uint {
		NoData,
		Good,
		Error
	}
}

