using System;
using MonoTouch.UIKit;
using MonoTouch.Foundation;
using MonoTouch.ObjCRuntime;

namespace GoogleAnalytics {

	public delegate void GAIDispatchResultHandler(GAIDispatchResult result);

	[Model, BaseType (typeof (NSObject))]
	public partial interface GAILogger {

		[Export ("logLevel")]
		GAILogLevel LogLevel { get; set; }

		[Export ("verbose:")]
		void Verbose (string message);

		[Export ("info:")]
		void Info (string message);

		[Export ("warning:")]
		void Warning (string message);

		[Export ("error:")]
		void Error (string message);
	}

	[Model, BaseType (typeof (NSObject))]
	public partial interface GAITracker {

		[Export ("name")]
		string Name { get; }

		[Export ("allowIDFACollection")]
		bool AllowIDFACollection { get; set; }

		[Export ("set:value:")]
		void Set (string parameterName, string value);

		[Export ("get:")]
		string Get (string parameterName);

		[Export ("send:")]
		void Send (NSDictionary parameters);
	}

	[BaseType (typeof (UIViewController))]
	public partial interface GAITrackedViewController {

		[Export ("tracker", ArgumentSemantic.Assign)]
		GAITracker Tracker { get; set; }

		[Export ("screenName", ArgumentSemantic.Copy)]
		string ScreenName { get; set; }
	}

	[BaseType (typeof (NSObject))]
	public partial interface GAI {

		[Export ("defaultTracker", ArgumentSemantic.Assign)]
		GAITracker DefaultTracker { get; set; }

		[Export ("logger", ArgumentSemantic.Retain)]
		GAILogger Logger { get; set; }

		[Export ("optOut")]
		bool OptOut { get; set; }

		[Export ("dispatchInterval")]
		double DispatchInterval { get; set; }

		[Export ("trackUncaughtExceptions")]
		bool TrackUncaughtExceptions { get; set; }

		[Export ("dryRun")]
		bool DryRun { get; set; }

		[Static, Export ("sharedInstance")]
		GAI SharedInstance { get; }

		[Export ("trackerWithName:trackingId:")]
		GAITracker TrackerWithName (string name, string trackingId);

		[Export ("trackerWithTrackingId:")]
		GAITracker TrackerWithTrackingId (string trackingId);

		[Export ("removeTrackerByName:")]
		void RemoveTrackerByName (string name);

		[Export ("dispatch")]
		void Dispatch ();

		[Export ("dispatchWithCompletionHandler:")]
		void DispatchWithCompletionHandler (GAIDispatchResultHandler completionHandler);
	}

	[BaseType (typeof (NSObject))]
	public partial interface GAIEcommerceProduct {

		[Export ("setId:")]
		GAIEcommerceProduct SetId (string productId);

		[Export ("setName:")]
		GAIEcommerceProduct SetName (string productName);

		[Export ("setBrand:")]
		GAIEcommerceProduct SetBrand (string productBrand);

		[Export ("setCategory:")]
		GAIEcommerceProduct SetCategory (string productCategory);

		[Export ("setVariant:")]
		GAIEcommerceProduct SetVariant (string productVariant);

		[Export ("setPrice:")]
		GAIEcommerceProduct SetPrice (NSNumber productPrice);

		[Export ("setQuantity:")]
		GAIEcommerceProduct SetQuantity (NSNumber productQuantity);

		[Export ("setCouponCode:")]
		GAIEcommerceProduct SetCouponCode (string productCouponCode);

		[Export ("setPosition:")]
		GAIEcommerceProduct SetPosition (NSNumber productPosition);

		[Export ("setCustomDimension:value:")]
		GAIEcommerceProduct SetCustomDimension (uint index, string value);

		[Export ("setCustomMetric:value:")]
		GAIEcommerceProduct SetCustomMetric (uint index, NSNumber value);

		[Export ("buildWithIndex:")]
		NSDictionary BuildWithIndex (uint index);

		[Export ("buildWithListIndex:index:")]
		NSDictionary BuildWithListIndex (uint lIndex, uint index);
	}

	[BaseType (typeof (NSObject))]
	public partial interface GAIEcommercePromotion {

		[Export ("setId:")]
		GAIEcommercePromotion SetId (string pid);

		[Export ("setName:")]
		GAIEcommercePromotion SetName (string name);

		[Export ("setCreative:")]
		GAIEcommercePromotion SetCreative (string creative);

		[Export ("setPosition:")]
		GAIEcommercePromotion SetPosition (string position);

		[Export ("buildWithIndex:")]
		NSDictionary BuildWithIndex (uint index);
	}

	[BaseType (typeof (NSObject))]
	public partial interface GAIDictionaryBuilder {

		[Export ("set:forKey:")]
		GAIDictionaryBuilder Set (string value, string key);

		[Export ("setAll:")]
		GAIDictionaryBuilder SetAll (NSDictionary parameters);

		[Export ("get:")]
		string Get (string paramName);

		[Export ("build")]
		NSMutableDictionary Build { get; }

		[Export ("setCampaignParametersFromUrl:")]
		GAIDictionaryBuilder SetCampaignParametersFromUrl (string urlString);

		[Static, Export ("createAppView")]
		GAIDictionaryBuilder CreateAppView { get; }

		[Static, Export ("createScreenView")]
		GAIDictionaryBuilder CreateScreenView { get; }

		[Static, Export ("createEventWithCategory:action:label:value:")]
		GAIDictionaryBuilder CreateEventWithCategory (string category, string action, string label, NSNumber value);

		[Static, Export ("createExceptionWithDescription:withFatal:")]
		GAIDictionaryBuilder CreateExceptionWithDescription (string description, NSNumber fatal);

		[Static, Export ("createItemWithTransactionId:name:sku:category:price:quantity:currencyCode:")]
		GAIDictionaryBuilder CreateItemWithTransactionId (string transactionId, string name, string sku, string category, NSNumber price, NSNumber quantity, string currencyCode);

		[Static, Export ("createSocialWithNetwork:action:target:")]
		GAIDictionaryBuilder CreateSocialWithNetwork (string network, string action, string target);

		[Static, Export ("createTimingWithCategory:interval:name:label:")]
		GAIDictionaryBuilder CreateTimingWithCategory (string category, NSNumber intervalMillis, string name, string label);

		[Static, Export ("createTransactionWithId:affiliation:revenue:tax:shipping:currencyCode:")]
		GAIDictionaryBuilder CreateTransactionWithId (string transactionId, string affiliation, NSNumber revenue, NSNumber tax, NSNumber shipping, string currencyCode);

		[Export ("setProductAction:")]
		GAIDictionaryBuilder SetProductAction (GAIEcommerceProductAction productAction);

		[Export ("addProduct:")]
		GAIDictionaryBuilder AddProduct (GAIEcommerceProduct product);

		[Export ("addProductImpression:impressionList:impressionSource:")]
		GAIDictionaryBuilder AddProductImpression (GAIEcommerceProduct product, string name, string source);

		[Export ("addPromotion:")]
		GAIDictionaryBuilder AddPromotion (GAIEcommercePromotion promotion);

		[Field ("kGAIProductId", "__Internal")]
		NSString GAIProductId { get; }

		[Field ("kGAIProductName", "__Internal")]
		NSString GAIProductName { get; }

		[Field ("kGAIProductBrand", "__Internal")]
		NSString GAIProductBrand { get; }

		[Field ("kGAIProductCategory", "__Internal")]
		NSString GAIProductCategory { get; }

		[Field ("kGAIProductVariant", "__Internal")]
		NSString GAIProductVariant { get; }

		[Field ("kGAIProductPrice", "__Internal")]
		NSString GAIProductPrice { get; }

		[Field ("kGAIProductQuantity", "__Internal")]
		NSString GAIProductQuantity { get; }

		[Field ("kGAIProductCouponCode", "__Internal")]
		NSString GAIProductCouponCode { get; }

		[Field ("kGAIProductPosition", "__Internal")]
		NSString GAIProductPosition { get; }

		[Field ("kGAIProductAction", "__Internal")]
		NSString GAIProductAction { get; }

		[Field ("kGAIPADetail", "__Internal")]
		NSString GAIPADetail { get; }

		[Field ("kGAIPAClick", "__Internal")]
		NSString GAIPAClick { get; }

		[Field ("kGAIPAAdd", "__Internal")]
		NSString GAIPAAdd { get; }

		[Field ("kGAIPARemove", "__Internal")]
		NSString GAIPARemove { get; }

		[Field ("kGAIPACheckout", "__Internal")]
		NSString GAIPACheckout { get; }

		[Field ("kGAIPACheckoutOption", "__Internal")]
		NSString GAIPACheckoutOption { get; }

		[Field ("kGAIPAPurchase", "__Internal")]
		NSString GAIPAPurchase { get; }

		[Field ("kGAIPARefund", "__Internal")]
		NSString GAIPARefund { get; }

		[Field ("kGAIPATransactionId", "__Internal")]
		NSString GAIPATransactionId { get; }

		[Field ("kGAIPAAffiliation", "__Internal")]
		NSString GAIPAAffiliation { get; }

		[Field ("kGAIPARevenue", "__Internal")]
		NSString GAIPARevenue { get; }

		[Field ("kGAIPATax", "__Internal")]
		NSString GAIPATax { get; }

		[Field ("kGAIPAShipping", "__Internal")]
		NSString GAIPAShipping { get; }

		[Field ("kGAIPACouponCode", "__Internal")]
		NSString GAIPACouponCode { get; }

		[Field ("kGAICheckoutStep", "__Internal")]
		NSString GAICheckoutStep { get; }

		[Field ("kGAICheckoutOption", "__Internal")]
		NSString GAICheckoutOption { get; }

		[Field ("kGAIProductActionList", "__Internal")]
		NSString GAIProductActionList { get; }

		[Field ("kGAIProductListSource", "__Internal")]
		NSString GAIProductListSource { get; }

		[Field ("kGAIImpressionName", "__Internal")]
		NSString GAIImpressionName { get; }

		[Field ("kGAIImpressionListSource", "__Internal")]
		NSString GAIImpressionListSource { get; }

		[Field ("kGAIImpressionProduct", "__Internal")]
		NSString GAIImpressionProduct { get; }

		[Field ("kGAIImpressionProductId", "__Internal")]
		NSString GAIImpressionProductId { get; }

		[Field ("kGAIImpressionProductName", "__Internal")]
		NSString GAIImpressionProductName { get; }

		[Field ("kGAIImpressionProductBrand", "__Internal")]
		NSString GAIImpressionProductBrand { get; }

		[Field ("kGAIImpressionProductCategory", "__Internal")]
		NSString GAIImpressionProductCategory { get; }

		[Field ("kGAIImpressionProductVariant", "__Internal")]
		NSString GAIImpressionProductVariant { get; }

		[Field ("kGAIImpressionProductPosition", "__Internal")]
		NSString GAIImpressionProductPosition { get; }

		[Field ("kGAIImpressionProductPrice", "__Internal")]
		NSString GAIImpressionProductPrice { get; }

		[Field ("kGAIPromotionId", "__Internal")]
		NSString GAIPromotionId { get; }

		[Field ("kGAIPromotionName", "__Internal")]
		NSString GAIPromotionName { get; }

		[Field ("kGAIPromotionCreative", "__Internal")]
		NSString GAIPromotionCreative { get; }

		[Field ("kGAIPromotionPosition", "__Internal")]
		NSString GAIPromotionPosition { get; }

		[Field ("kGAIPromotionAction", "__Internal")]
		NSString GAIPromotionAction { get; }

		[Field ("kGAIPromotionView", "__Internal")]
		NSString GAIPromotionView { get; }

		[Field ("kGAIPromotionClick", "__Internal")]
		NSString GAIPromotionClick { get; }
	}

	[BaseType (typeof (NSObject))]
	public partial interface GAIEcommerceFields {

		[Static, Export ("productFieldForIndex:suffix:")]
		string ProductFieldForIndex (uint index, string suffix);

		[Static, Export ("impressionListForIndex:")]
		string ImpressionListForIndex (uint index);

		[Static, Export ("productImpressionForList:index:suffix:")]
		string ProductImpressionForList (string list, uint index, string Suffix);

		[Static, Export ("promotionForIndex:suffix:")]
		string PromotionForIndex (uint index, string suffix);
	}

	[BaseType (typeof (NSObject))]
	public partial interface GAIEcommerceProductAction {

		[Export ("setAction:")]
		GAIEcommerceProductAction SetAction (string productAction);

		[Export ("setTransactionId:")]
		GAIEcommerceProductAction SetTransactionId (string transactionId);

		[Export ("setAffiliation:")]
		GAIEcommerceProductAction SetAffiliation (string affiliation);

		[Export ("setRevenue:")]
		GAIEcommerceProductAction SetRevenue (NSNumber revenue);

		[Export ("setTax:")]
		GAIEcommerceProductAction SetTax (NSNumber tax);

		[Export ("setShipping:")]
		GAIEcommerceProductAction SetShipping (NSNumber shipping);

		[Export ("setCouponCode:")]
		GAIEcommerceProductAction SetCouponCode (string couponCode);

		[Export ("setCheckoutStep:")]
		GAIEcommerceProductAction SetCheckoutStep (NSNumber checkoutStep);

		[Export ("setCheckoutOption:")]
		GAIEcommerceProductAction SetCheckoutOption (string checkoutOption);

		[Export ("setProductActionList:")]
		GAIEcommerceProductAction SetProductActionList (string productActionList);

		[Export ("setProductListSource:")]
		GAIEcommerceProductAction SetProductListSource (string productListSource);

		[Export ("build")]
		NSDictionary Build { get; }
	}

	[BaseType (typeof (NSObject))]
	public partial interface GAIFields {

		[Static, Export ("contentGroupForIndex:")]
		string ContentGroupForIndex (uint index);

		[Static, Export ("customDimensionForIndex:")]
		string CustomDimensionForIndex (uint index);

		[Static, Export ("customMetricForIndex:")]
		string CustomMetricForIndex (uint index);
	}
}
